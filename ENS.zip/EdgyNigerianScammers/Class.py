class Requise:
    color = "#000099"
    def __init__(self,color,radius):
        self.color = color
        self.radius = radius
    radius = 8
    def printColor(self):
        print("Colors:", self.color)
    def printRadius(self):
        print("Radius:", self.radius)

redCircle = Requise("#990000", 55)
greenCircle = Requise("#009900", 100)

redCircle.printColor()
greenCircle.printColor()















"""
circleObj1 = Requise()
circleObj2 = Requise()

circleObj1.color = "Black"
circleObj2.color = "Fulvous"

circleObj1.printColor()
circleObj2.printColor()

circleObj1.radius = 10000000000000000
circleObj2.radius = 12

circleObj1.printRadius()
circleObj2.printRadius()

"""