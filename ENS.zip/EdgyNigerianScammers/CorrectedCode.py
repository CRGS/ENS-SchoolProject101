names1 = ["Pete", "Steve", "Joe", "Joe", "Janice", "Rebecca", "Julie", "Steve"]

uniqueNames = []



for name in names1:

    print("Checking " + name + " For uniqueness")

    if name not in uniqueNames:

        uniqueNames.append(name)



print(uniqueNames)