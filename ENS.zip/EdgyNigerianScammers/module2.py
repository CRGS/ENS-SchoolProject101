class Circle:
    color = "#000099"
    radius = 0
    def __init__(self,color,radius):
        self.color = color
        self.radius = radius
    def printColor(self):
        print(self.color)
    def printRadius(self):
        print(self.radius)


redCircle = Circle("#990000", 55)
greenCircle = Circle("009900", 100)

redCircle.printColor()
greenCircle.printColor()


class PingPongBall(object):
    def __init__(self, myRadius, myColor):
        self.radius = myRadius
        self.color = myColor

    def draw_circle(self, diameter):
        print("A circle was drawn with a diameter of:", diameter, "and a color of:", self.color)

mike = PingPongBall(50, "#00FF00")
print(mike.color)
print(mike.draw_circle(20))

emily = PingPongBall(100, "#FF00FF")
print(emily.color)
print(emily.draw_circle(20))

ballList = []

ballList.append(mike)
ballList.append(emily)

print(ballList[1].draw_circle(200))

print(ballList[0].draw_circle(500))